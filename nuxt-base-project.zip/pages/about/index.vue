<script>
import Index from '~/pages/about/_lang/index'
export default Index
</script>