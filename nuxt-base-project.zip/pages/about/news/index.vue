<template />

<script>
export default {
  name: 'AboutNewsPage',
  data() {
    return {
      title: 'Hello World!',
    }
  },
  head() {
    return {
      title: '关于我们 - 企业新闻',
    }
  },
}
</script>
