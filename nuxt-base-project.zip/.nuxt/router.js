import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _dd2a95b0 = () => interopDefault(import('..\\pages\\about\\index.vue' /* webpackChunkName: "pages/about/index" */))
const _11679675 = () => interopDefault(import('..\\pages\\about\\news\\index.vue' /* webpackChunkName: "pages/about/news/index" */))
const _0c5d657f = () => interopDefault(import('..\\pages\\about\\_lang\\index.vue' /* webpackChunkName: "pages/about/_lang/index" */))
const _2b0648df = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _0d1d85e8 = () => interopDefault(import('..\\pages\\_lang\\index.vue' /* webpackChunkName: "pages/_lang/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _dd2a95b0,
    name: "about"
  }, {
    path: "/about/news",
    component: _11679675,
    name: "about-news"
  }, {
    path: "/about/:lang",
    component: _0c5d657f,
    name: "about-lang"
  }, {
    path: "/",
    component: _2b0648df,
    name: "index"
  }, {
    path: "/:lang",
    component: _0d1d85e8,
    name: "lang"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
